import Surveyform from "./view/survey-form/surveyform";

function App() {
  return (
    <div>
      <Surveyform />
    </div>
  );
}

export default App;
